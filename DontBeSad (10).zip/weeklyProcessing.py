import pandas as pd
from statistics import stdev
import os
from replit import db
import sqlite3

def dbToTableList(con,cursor):
    #con = sqlite3.connect("userDataAnalysis.db")
    #cursor = con.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tableListArr = cursor.fetchall()
    tableList = [0]*len(tableListArr)
    index =0

    for arr in tableListArr:
        tableList[index] = str(arr[0])
        index = index+1
    
    return tableList

def toCsvInOne(tableList,con):
    for table in tableList:
        db_df = pd.read_sql_query("SELECT * FROM "+ table+ ";", con)
        db_df['userId']=table#tag with userId for later processing
        db_df.to_csv('userdataThisWeek.csv', mode='a',index=False)

def removingTheIrrelevantData(tableList,data):
  formatCsv = "id,sent"
  with open('relevantData.csv','a') as fd:
    fd.write(formatCsv)
  with open('irrelevantData.csv','a') as fd:
    fd.write(formatCsv)
  for table in tableList:
    dataPersonal = data[data.userId == table]
    dataPersonalSent = dataPersonal.msgIntensity.astype(float)
    dataNumber = dataPersonal.msgNumber.astype(int)
    dataPersonalMax = dataNumber.max()
    if(dataPersonalMax>100):
        dataPersonalMean = dataPersonalSent.mean()
        dataToCsv = table+","+str(dataPersonalMean)
        blank = "\n"
        with open('relevantData.csv','a') as fd:
            fd.write(blank)
            fd.write(dataToCsv)
    else:
        dataPersonalMean = dataPersonalSent.mean()
        dataToCsv = table+","+str(dataPersonalMean)
        blank = "\n"
        with open('irrelevantData.csv','a') as fd:
            fd.write(blank)
            fd.write(dataToCsv)
          
def getWeekSentimentAverage(data):
    dataSent = data.sent.astype(float)
    weekMean = dataSent.mean()
    return(weekMean)
    
def getWeekStandardDeviation(data):
    sentiments = []
    for i in data.sent.astype(float):
        sentiments.append(i)
    try:
      stanDev = stdev(sentiments)
    except:
      stanDev = 0
    return stanDev
    
    
def Average(lst):
    return sum(lst) / len(lst)

def processingToDatabase(tableList,average,stdevWeek,data):
    processed = []
    notEnoughData = []
    ciaList = []#list of users that are extremist
    
    for table in tableList:
        dataPersonal = data[data.userId == table]
        dataPersonalSent = dataPersonal.msgIntensity.astype(float)
        dataNumber = dataPersonal.msgNumber.astype(int)
        dataEmotion = dataPersonal[dataPersonal.msgEmotion != "neutral"]
        dataEmotion = dataEmotion.msgEmotion.astype(str)
        try:
            dataEmotionCommon = dataEmotion.value_counts().idxmax()
        except:
            dataEmotionCommon = "neutral"
        dataPersonalMax = dataNumber.max()
        dataPersonalMean = dataPersonalSent.mean()
        isExtreme = 0 #whether the emotion is considered extreme or not
        if(dataPersonalMean <average-0.002-stdevWeek or dataPersonalMean >average+0.002+stdevWeek):
            isExtreme = 1
            ciaList.append(table)
            
        if(dataPersonalMax>1):
            dataToDb = (str(dataPersonalMean),str(dataEmotionCommon),isExtreme,table)
            processed.append(dataToDb)
        else:
            dataToDb = (str(dataPersonalMean),str(dataEmotionCommon),isExtreme,table)
            notEnoughData.append(dataToDb)
    return (processed,notEnoughData,ciaList)

def convertIntoDatabase(processed,stdevWeek):
  #dbstructure : [week,sentiment,emotion]
  #('-0.07734203821656054', 'anger', 1, 'id237185711504097280')
  dbKeys = db.keys()
  for i in processed:
    if((i[3])in dbKeys):
      prevWeek = db[i[3]]
      prevIteration = prevWeek[0]
      print(i[0])
      prevWeek1 = prevWeek[1]#this is still a list idk why
      if(type(prevWeek1)==float):#there's a bug where the sentiments are sometimes a list and sometimes a float, that's why there's this condition
        sentimentTotal = [(float(i[0]))+float(prevWeek1)/(prevIteration+1)]
      else:
        sentimentTotal = [(float(i[0]))+float(prevWeek1[0])/(prevIteration+1)]
      db[i[3]] = [prevIteration+1,sentimentTotal,i[1]]
    else:
      db[i[3]] = [1,float(i[0]),i[1]]
    for i in stdevWeek:
      if((i[3])in dbKeys):
        prevWeek = db[i[3]]
        prevIteration = prevWeek[0]
        prevWeek1 = prevWeek[1]#this is still a list idk why
        if(type(prevWeek1)==float):#there's a bug where the sentiments are sometimes a list and sometimes a float, that's why there's this condition
          sentimentTotal = [(float(i[0]))+float(prevWeek1)/(prevIteration+1)]
        else:
          sentimentTotal = [(float(i[0]))+float(prevWeek1[0])/(prevIteration+1)]
        db[i[3]] = [prevIteration,sentimentTotal,i[1]]
      else:
        db[i[3]] = [0,float(i[0]),i[1]]
    
    

def weeklyEvaluation(con,cursor):
  try:
    os.remove('relevantData.csv')
    os.remove('irrelevantData.csv')
  except:  
    a =1#change to do nothing later
  tableList =  dbToTableList(con,cursor)
  toCsvInOne(tableList,con)
  dataWeeklyPd = pd.read_csv('userdataThisWeek.csv')#drop usedatathisweeklater
  dataWeeklyPd = dataWeeklyPd[dataWeeklyPd.msgNumber != "msgNumber"]
  removingTheIrrelevantData(tableList,dataWeeklyPd)
  relData = pd.read_csv('relevantData.csv')
  average = getWeekSentimentAverage(relData)
  stdevWeek = getWeekStandardDeviation(relData)
  (processed,notEnoughData,ciaList) = processingToDatabase(tableList,average,stdevWeek,dataWeeklyPd)
  convertIntoDatabase(processed,notEnoughData)
  abcd = []
  dbKeys = db.keys()
  try:
    os.remove('userdataThisWeek.csv')
  except:  
    a =1
  try:
    os.remove('userData.db')
  except:  
    a =1
  
  database = sqlite3.connect('userData.db')
  
  for i in processed:
    if((i[3])in dbKeys):
      value = db[i[3]]
      abcd.append(value[0])
  for i in processed:
    #value = db[i[3]]
    #abcd.append(value[0])
    if((i[3])in dbKeys):
      del db[i[3]]
  for i in notEnoughData:
    if((i[3])in dbKeys):
      del db[i[3]]
  
  return(abcd)

"""x = input()
db_keys = db.keys()
if x in db_keys:
  print(f"{x} is a key")
else:
  print(f"{x} is not a key")"""