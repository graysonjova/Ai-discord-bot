import os
import discord
import requests
#cross validation, don't forget
import json
import base64
import random
import datetime
import nltk
nltk.download('wordnet')
nltk.download('omw-1.4')
from processing import emoteProcess
from processing import discUserNameClean
from databaseProcessing import storeData
from databaseProcessing import getMostCommonEmotionDaily
from databaseProcessing import getMostCommonEmotionWeekly
from weeklyProcessing import weeklyEvaluation
import sqlite3
from processing import timeInf
from processing import sendHelp
from chatBot import query
from replit import db
import keep_alive
import asyncio
headers = {'Authorization': 'Bearer {}'.format("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")}
apiURL = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-large"

apiURLAnime = API_URL = "https://api-inference.huggingface.co/models/grayson124/chatbotwaifu"

emoteBot = 0
client = discord.Client()

jokeList = [
    "Why do the chicken cross the road? Because idk , this joke has never been funny",
    "Joke1", "Joke2", "more joke"
]
joke = ["$joke", "$funny"]


def getInspiringPic():

    response = requests.get("https://zenquotes.io/api/random")
    json_data = json.loads(response.text)
    quote = json_data[0]['q']
    return quote


database = sqlite3.connect('userData.db')
c = database.cursor()


async def weekly_review():
	while True:
		now = datetime.datetime.now()
		then = now+datetime.timedelta(days=1)
		wait_time = (then-now).total_seconds()
		await asyncio.sleep(wait_time)

		channel = client.get_channel(936814364017704981)

		await channel.send("Good morning!!")


@client.event
async def on_ready():
    print('Dont be sad bot, reporting to duty. hello {0.user}'.format(client))
    emoteBot = 0
    #mytask.start()
    await weekly_review()
    return (emoteBot)


@client.event
async def on_message(msg):
    authorMsg = str(msg.author)
    authorId = "id" + str(msg.author.id)

    authorMsg = discUserNameClean(authorMsg)
    serverId = msg.guild.id
    strServerId = str(serverId)

    if (msg.author == client.user):#This is where i would use switch... IF PYTHON HAVE ONE
        return

      
    elif (msg.content.startswith('$my emotion today')):
        emotionToday = getMostCommonEmotionDaily(authorId, c, database)
        await msg.channel.send("Today you are feeling " + emotionToday)


      
    elif (msg.content.startswith('$my emotion this week')):  
        emotionThisWeek = getMostCommonEmotionWeekly(authorId, c, database)
        await msg.channel.send("This week you are feeling " + emotionThisWeek)
        msgPrivate = sendHelp(emotionThisWeek)
        user = await client.fetch_user(msg.author.id)
        await user.send(msgPrivate)
      
        


  
    elif (msg.content.startswith('$gibQuote')):
        quote = getInspiringPic()
        await msg.channel.send(quote)


      
    elif (msg.content.startswith('$start')):
        emoteBot = 1
        await msg.channel.send(emoteBot)
        return (emoteBot)


      
    elif (msg.content.startswith('$sendMsg')):
      await msg.channel.send(msg.author.id)
      user = await client.fetch_user(msg.author.id)
      await user.send('test')
    # This works ^


      
    elif (msg.content.startswith('$chatbotOn')):
        serverId = msg.guild.id
        strServerId = str(serverId)
        db[strServerId] = [1, 0, 0]
        #serverId[0] = 1
        botStatus = db[strServerId]
        await msg.channel.send("chatbot Online")
        await msg.channel.send(id)

    elif (msg.content.startswith('$chatbotAnime')):
        serverId = msg.guild.id
        strServerId = str(serverId)
        db[strServerId] = [2, 0, 0]
        #serverId[0] = 1
        botStatus = db[strServerId]
        await msg.channel.send("Anime Dialogue Bot online")
        await msg.channel.send(id)

      
    elif (msg.content.startswith('$messageTesting')):
        tableList = weeklyEvaluation(database,c)
        await msg.channel.send(tableList)
    elif (msg.content.startswith('$testing234')):#delete later
        await msg.channel.send(msg.channel.id)
      
    elif (msg.content.startswith('$chatbotOff')):
        serverId = msg.guild.id
        strServerId = str(serverId)
        db[strServerId] = [0, 0, 0]
        #serverId[0] = 1
        botStatus = db[strServerId]
        await msg.channel.send("chatbot Offline")
        await msg.channel.send(id)

    elif any(word in msg.content for word in joke):
        await msg.channel.send(msg.author)
        await msg.channel.send(random.choice(jokeList))
      
    else:
        if (strServerId in db.keys()):
            status = db[strServerId]
            if (status[0] == 1):#status[0]
                payload = {'inputs': {'text': msg.content}}
                chatbotMessage = query(payload, apiURL, headers)
                botResponse = chatbotMessage.get('generated_text', None)
                await msg.channel.send(botResponse)
                emotion = emoteProcess(msg.content)
                datacheck = storeData(emotion, authorId, msg.content, c,
                                      database)


              
            elif (status[0] == 2):#status[0]
                payload = {'inputs': {'text': msg.content}}
                chatbotMessage = query(payload, apiURLAnime, headers)
                botResponse = chatbotMessage.get('generated_text', None)
                await msg.channel.send(botResponse)
                emotion = emoteProcess(msg.content)
                datacheck = storeData(emotion, authorId, msg.content, c,
                                      database)
        



              
            else:
                emotion = emoteProcess(msg.content)
                datacheck = storeData(emotion, authorId, msg.content, c,
                                      database)
            
        else:
            emotion = emoteProcess(msg.content)
            datacheck = storeData(emotion, authorId, msg.content, c, database)
        database.commit()

        #await msg.channel.send(emotion)
from discord.ext import tasks 
#1 day
#async def mytask():
#  await msg.channel.send(msg.author)
  

discordToken = os.environ['discordToken']
keep_alive.keep_alive()
client.run(discordToken)

